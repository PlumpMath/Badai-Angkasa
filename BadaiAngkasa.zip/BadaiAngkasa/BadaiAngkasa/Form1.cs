﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using WMPLib;

using SharpGL;
using SharpGL.SceneGraph.Assets;

using AForge.Imaging;
using AForge.Video;
using AForge.Video.DirectShow;

/// <summary>
/// Iman, December 2017.
/// </summary>
namespace BadaiAngkasa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // ==================================================================================================== Declarations

        OpenGL GL;

        Random RandomInstance;

        struct Vector3f
        {
            public float X;
            public float Y;
            public float Z;
            public Vector3f(float x, float y, float z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }

        Texture TitleTexture;
        Texture InfoTexture;
        Texture StarTexture;
        Texture BodyTexture;
        Texture CockpitTexture;
        Texture NoseTexture;
        Texture WingTexture;
        Texture EmissionTexture;
        Texture BeamTexture;
        Texture[] MeteorTextures;
        Texture ExplosionTexture;
        Texture HitTexture;
        Texture FinalScoreTexture;
        Texture[] ScoreTextures;

        WindowsMediaPlayer MediaPlayerTheme;
        WindowsMediaPlayer[] MediaPlayerEffect;

        IWMPMedia ThemeSound1;
        IWMPMedia ThemeSound2;
        IWMPMedia PlaySound;
        IWMPMedia BeamSound;
        IWMPMedia ExplodeSound;
        IWMPMedia HitSound;

        bool GAME_READY;
        bool GAME_BEGINS;
        bool GAME_ENDS;

        public float Difficulty;

        struct Player
        {
            public Vector3f Position;
            public float Rotation;
            public float Speed;
            public float MaxSpeed;
            public Vector3f Boundary;
            public bool MoveLeft, MoveRight, Shooting;
            public int Score;
            public ushort Health;
        }
        Player ThePlayer;

        struct Meteor
        {
            public bool Active;
            public int Type;
            public Vector3f Position;
            public float Angle;
            public Vector3f Rotation;
            public float Speed;
            public void Reset(Random rndm, float boundaryX, float boundaryY, float difficulty)
            {
                float xValue = (float)rndm.NextDouble() * (boundaryX + 4f) - ((boundaryX + 4f) / 2);
                Position = new Vector3f(
                    xValue,
                    (1 - Math.Abs(xValue / boundaryX)) * -boundaryY,
                    -24f);
                Angle = (float)rndm.NextDouble() * 359f;
                Rotation = new Vector3f((float)rndm.NextDouble(), (float)rndm.NextDouble(), (float)rndm.NextDouble());
                Speed = 0.25f + (float)rndm.NextDouble() * difficulty;
                Type = rndm.Next(3);
                Active = true;
            }
        }
        Meteor[] Meteors;

        struct Beam
        {
            public bool Active;
            public Vector3f Position;
            public float Angle;
            public Vector3f Rotation;
            public float Speed;
            public void Reset(Vector3f pos, float angl, Vector3f rot)
            {
                Position = pos;
                Angle = angl;
                Rotation = rot;
            }
        }
        Beam[] Beams;

        struct Explosion
        {
            public bool Active;
            public Vector3f Position;
            public Vector3f DefaultScale;
            public Vector3f Scale;
            public float Speed;
            public void Reset(Vector3f pos, float spd)
            {
                Position = pos;
                Speed = spd;
                Scale = DefaultScale;
                Active = true;
            }
        }
        Explosion[] Explosions;

        struct HitEffect
        {
            public bool Active;
            public Vector3f Position;
            public Vector3f DefaultScale;
            public Vector3f Scale;
            public float Speed;
            public void Reset(Vector3f pos)
            {
                Position = pos;
                Scale = DefaultScale;
                Active = true;
            }
        }
        HitEffect TheHitEffect;

        struct ScoreEffect
        {
            public bool Active;
            public Vector3f Position;
            public float Speed;
            public void Reset(Vector3f pos)
            {
                Position = pos;
                Active = true;
            }
        }
        ScoreEffect[] ScoreEffects;

        int ChangingValue;
        bool ChangingValueIncrease;

        // This part belongs to webcam input.

        /// <summary>
        /// Keeps the previous image's colors obtained from camera.
        /// </summary>
        public Color[,] PreviousImage;
        /// <summary>
        /// The subtraction result of current and previous image.
        /// </summary>
        public Color[,] SubtractionResult;
        /// <summary>
        /// Polarization result of boosted colors.
        /// </summary>
        public Color[,] PolarizationResult;
        /// <summary>
        /// Representation of image's part to be processed.
        /// </summary>
        struct ImagePart
        {
            public Rectangle Area;
            public int TotalWhiteDetected;
        }
        ImagePart[] ImageParts;
        /// <summary>
        /// The minimum pixel area allowed to say that this is a white object (value should be square).
        /// </summary>
        public int MinimumWhitePixel;

        // ==================================================================================================== Main functions

        /// <summary>
        /// Initialize stuff.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TheOpenGLControl_Load(object sender, EventArgs e)
        {
            GL = this.TheOpenGLControl.OpenGL;

            RandomInstance = new Random();

            TitleTexture = new Texture(); TitleTexture.Create(GL, "Assets/Title.png");
            InfoTexture = new Texture(); InfoTexture.Create(GL, "Assets/Info.png");
            StarTexture = new Texture(); StarTexture.Create(GL, "Assets/Star.png");
            BodyTexture = new Texture(); BodyTexture.Create(GL, "Assets/Body 1.png");
            CockpitTexture = new Texture(); CockpitTexture.Create(GL, "Assets/Cockpit.png");
            NoseTexture = new Texture(); NoseTexture.Create(GL, "Assets/Nose 1.png");
            WingTexture = new Texture(); WingTexture.Create(GL, "Assets/Wing 1.png");
            EmissionTexture = new Texture(); EmissionTexture.Create(GL, "Assets/Emission 1.png");
            BeamTexture = new Texture(); BeamTexture.Create(GL, "Assets/Beam 1.png");
            MeteorTextures = new Texture[3];
            MeteorTextures[0] = new Texture(); MeteorTextures[0].Create(GL, "Assets/Meteor 1.png");
            MeteorTextures[1] = new Texture(); MeteorTextures[1].Create(GL, "Assets/Meteor 2.png");
            MeteorTextures[2] = new Texture(); MeteorTextures[2].Create(GL, "Assets/Meteor 3.png");
            ExplosionTexture = new Texture(); ExplosionTexture.Create(GL, "Assets/Explosion.png");
            HitTexture = new Texture(); HitTexture.Create(GL, "Assets/Hit.png");
            FinalScoreTexture = new Texture(); FinalScoreTexture.Create(GL, "Assets/Final Score.png");
            ScoreTextures = new Texture[3];
            ScoreTextures[0] = new Texture(); ScoreTextures[0].Create(GL, "Assets/Score 1.png");
            ScoreTextures[1] = new Texture(); ScoreTextures[1].Create(GL, "Assets/Score 2.png");
            ScoreTextures[2] = new Texture(); ScoreTextures[2].Create(GL, "Assets/Score 3.png");

            MediaPlayerTheme = new WindowsMediaPlayer(); // Create media player object to play music theme.
            MediaPlayerTheme.settings.autoStart = false;

            MediaPlayerEffect = new WindowsMediaPlayer[3]; // Create media player objects to play Sfx.
            for(int a=0; a<MediaPlayerEffect.Length; a++)
            {
                MediaPlayerEffect[a] = new WindowsMediaPlayer();
                MediaPlayerEffect[a].settings.autoStart = false;
            }

            ThemeSound1 = MediaPlayerTheme.newMedia("Assets/Space Storm.wav"); // Create media object.
            ThemeSound2 = MediaPlayerTheme.newMedia("Assets/Space Storm is Over.wav");
            PlaySound = MediaPlayerEffect[0].newMedia("Assets/Play.wav");
            BeamSound = MediaPlayerEffect[0].newMedia("Assets/Beam.wav");
            ExplodeSound = MediaPlayerEffect[0].newMedia("Assets/Explode.wav");
            HitSound = MediaPlayerEffect[0].newMedia("Assets/Hit.wav");

            MediaPlayerTheme.currentMedia = ThemeSound1; MediaPlayerTheme.controls.play(); // Play theme sound.

            GAME_READY = true;
            GAME_BEGINS = false;
            GAME_ENDS = false;

            Difficulty = 0.5f;

            ThePlayer.Position = new Vector3f(0f, 0f, 0f);
            ThePlayer.Rotation = 0f;
            ThePlayer.Speed = 0f;
            ThePlayer.MaxSpeed = 0.5f;
            ThePlayer.Boundary = new Vector3f(4f, 2.25f, 0f);
            ThePlayer.MoveLeft = ThePlayer.MoveRight = ThePlayer.Shooting = false;
            ThePlayer.Score = 0;
            ThePlayer.Health = 100;


            Meteors = new Meteor[8];
            for (int a = 0; a < Meteors.Length; a++)
            {
                Meteors[a].Active = false;
                Meteors[a].Speed = 0.05f;
                Meteors[a].Reset(RandomInstance, ThePlayer.Boundary.X + 6f, ThePlayer.Boundary.Y, Difficulty);
            }

            Beams = new Beam[10];
            for (int a = 0; a < Beams.Length; a++)
            {
                Beams[a].Active = false;
                Beams[a].Speed = 0.75f;
                Beams[a].Reset(ThePlayer.Position, ThePlayer.Rotation, new Vector3f(0f, 0f, 1f));
            }

            Explosions = new Explosion[5];
            for (int a = 0; a < Explosions.Length; a++)
            {
                Explosions[a].DefaultScale = new Vector3f(2.07f, 2.07f, 1f);
                Explosions[a].Reset(new Vector3f(0f, 0f, 0f), 0.05f);
                Explosions[a].Active = false;
            }

            TheHitEffect = new HitEffect();
            TheHitEffect.DefaultScale = new Vector3f(7f, 7f, 1f);
            TheHitEffect.Speed = 0.75f;
            TheHitEffect.Active = false;

            ScoreEffects = new ScoreEffect[5];
            for (int a = 0; a < ScoreEffects.Length; a++)
            {
                ScoreEffects[a].Speed = 0.6f;
                ScoreEffects[a].Position = new Vector3f(0f, 0f, 0f);
                ScoreEffects[a].Active = false;
            }

            ChangingValue = 0;
            ChangingValueIncrease = true;

            // This part belongs to webcam input.
            MinimumWhitePixel = 100;
            // Open camera device.
            OpenLocalCamera();
        }

        /// <summary>
        /// Main OpenGL drawing function.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TheOpenGLControl_OpenGLDraw(object sender, RenderEventArgs e)
        {
            
            GL = this.TheOpenGLControl.OpenGL; //  Get the OpenGL object, just to clean up the code.
            GL.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer
            GL.LoadIdentity(); // Reset The View
            GL.Enable(OpenGL.GL_TEXTURE_2D); // Re-Enable texture.
            GL.Enable(OpenGL.GL_BLEND); // Enable blend function.
            GL.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);
            DrawStars(150, StarTexture, 0.25f, new Vector3f(43f, 23f, -30f)); // Render the background.
            GL.Translate(0f, 0.25f, -6f); // Set zero points in sightable area.

            // ------------------------------------------------------------------------------------------- Main game logic


            if (GAME_BEGINS)
            {
                StarShip(ThePlayer.Position, ThePlayer.Rotation, new Vector3f(0f, 0f, 1f)); // Render the player.  

                BeamManifest(); // Render player's beams.

                MeteorManifest(); // Render obstacles.

                ExplosionManifest(); // Render explosions.

                HitManifest(); // Render hit effect.

                ScoreEffectManifest(); // Render rewards.
            }

            DrawUI(); // Render UI.

            if(GAME_BEGINS)
                LineSight(); // Render line.

            // -----------------------------------------------------------------------------------------------------------

            GL.Flush();

            MediaPlayerListener(); // Handle sounds.
        }

        private void KeyDownListener(object sender, KeyEventArgs e)
        {
            // Game states.
            if (GAME_READY)
            {
                if (e.KeyCode == System.Windows.Forms.Keys.Return)
                {
                    GAME_READY = false;
                    GAME_BEGINS = true;
                    ThePlayer.Score = 0;
                    ThePlayer.Health = 100;
                    Difficulty = 0.5f;
                    for (int a = 0; a < Meteors.Length; a++)
                    {
                        Meteors[a].Speed = 0.05f;
                        Meteors[a].Reset(RandomInstance, ThePlayer.Boundary.X + 6f, ThePlayer.Boundary.Y, Difficulty);
                    }
                    MediaPlayerTheme.settings.volume = 35;
                    PlaySoundEffect(PlaySound);
                }
            } else if (GAME_BEGINS)
            {
                // Movements.
                if (e.KeyCode == System.Windows.Forms.Keys.A)
                {
                    ThePlayer.MoveLeft = true;
                }
                else
                {
                    if (e.KeyCode == System.Windows.Forms.Keys.D)
                    {
                        ThePlayer.MoveRight = true;
                    }
                }
                // Shooting.
                if (e.KeyCode == System.Windows.Forms.Keys.K)
                {
                    ThePlayer.Shooting = true;
                    PlaySoundEffect(BeamSound);
                }
                // Back.
                if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                {
                    GAME_READY = true;
                    GAME_BEGINS = false;
                    GAME_ENDS = false;
                    MediaPlayerTheme.settings.volume = 50;
                    PlaySoundEffect(PlaySound);
                }
            } else if (GAME_ENDS)
            {
                // Back.
                if (e.KeyCode == System.Windows.Forms.Keys.Escape)
                {
                    GAME_READY = true;
                    GAME_BEGINS = false;
                    GAME_ENDS = false;
                    MediaPlayerTheme.controls.stop();
                    MediaPlayerTheme.currentMedia = ThemeSound1;
                    MediaPlayerTheme.settings.volume = 50;
                    PlaySoundEffect(PlaySound);
                }
            }
        }

        private void KeyPressListener(object sender, KeyPressEventArgs e)
        {

        }

        private void KeyUpListener(object sender, KeyEventArgs e)
        {
            // Movements.
            if (e.KeyCode == System.Windows.Forms.Keys.A)
            {
                ThePlayer.MoveLeft = false;
            }
            else
            {
                if (e.KeyCode == System.Windows.Forms.Keys.D)
                {
                    ThePlayer.MoveRight = false;
                }
            }
            // Shooting.
            if (e.KeyCode == System.Windows.Forms.Keys.Space)
            {
                ThePlayer.Shooting = false;
            }
        }

        private void TheTimerTick(object sender, EventArgs e)
        {
            if (ChangingValueIncrease)
            {
                ChangingValue++;
                if (ChangingValue > 9)
                    ChangingValueIncrease = false;
            }
            else
            {
                ChangingValue--;
                if (ChangingValue < 1)
                    ChangingValueIncrease = true;
            }
        }

        private void MediaPlayerListener()
        {
            // Repeat theme sound.
            if (MediaPlayerTheme.playState == WMPPlayState.wmppsStopped || MediaPlayerTheme.playState == WMPPlayState.wmppsReady)
                MediaPlayerTheme.controls.play();
        }

        private void WebcamListener(object sender, ref Bitmap image)
        {
            if (GAME_BEGINS)
            {
                UnmanagedImage unmanagedImage = UnmanagedImage.FromManagedImage(image);
                // Process image data in each part.
                for (int c = 0; c < ImageParts.Length; c++)
                {
                    // Reset total white detected.
                    ImageParts[c].TotalWhiteDetected = 0;
                    for (int a = ImageParts[c].Area.X; a < ImageParts[c].Area.Width; a++)
                    {
                        for (int b = ImageParts[c].Area.Y; b < ImageParts[c].Area.Height; b++)
                        {
                            // Get the subtracted color.
                            // -------------------------------------------------------------------------------
                            SubtractionResult[a, b] = Color.FromArgb
                            (
                                255,
                                Math.Abs(unmanagedImage.GetPixel(a, b).R - PreviousImage[a, b].R),
                                Math.Abs(unmanagedImage.GetPixel(a, b).G - PreviousImage[a, b].G),
                                Math.Abs(unmanagedImage.GetPixel(a, b).B - PreviousImage[a, b].B)
                            );

                            // Get the highest value between R, G, and B.
                            // -------------------------------------------------------------------------------
                            int highestValue = Math.Max(Math.Max(
                                SubtractionResult[a, b].R, SubtractionResult[a, b].G),
                                SubtractionResult[a, b].B);

                            // Get the polarized color.
                            // -------------------------------------------------------------------------------
                            if (highestValue > 64)
                            {
                                // Set it to white.
                                PolarizationResult[a, b] = Color.White;
                                // Increase counter.
                                ImageParts[c].TotalWhiteDetected++;
                            }
                            else
                                // Set it to black.
                                PolarizationResult[a, b] = Color.Black;

                            // Save current color.
                            // -------------------------------------------------------------------------------
                            PreviousImage[a, b] = unmanagedImage.GetPixel(a, b);

                            // Apply results into bitmap and mirror it.
                            // -------------------------------------------------------------------------------
                            image.SetPixel(a, b, PolarizationResult[a, b]);
                        }
                    }
                }
                // Handle inputs.
                if (ImageParts[1].TotalWhiteDetected > MinimumWhitePixel)
                    ThePlayer.MoveLeft = true;
                else
                    ThePlayer.MoveLeft = false;
                if (ImageParts[0].TotalWhiteDetected > MinimumWhitePixel)
                    ThePlayer.MoveRight = true;
                else
                    ThePlayer.MoveRight = false;
                if (ImageParts[2].TotalWhiteDetected > MinimumWhitePixel * 4)
                {
                    ThePlayer.Shooting = true;
                    PlaySoundEffect(BeamSound);
                }
                else
                    ThePlayer.Shooting = false;
            }
        }

        private void FormClosed(object sender, FormClosingEventArgs e)
        {
            VideoPlayer.SignalToStop();
            VideoPlayer.Stop();
        }

        // ==================================================================================================== Other functions

        private void DrawStars(int totalStars, Texture star, float starSize, Vector3f boundary)
        {
            // Create random variables.
            Random rndm = new Random();
            Vector3f randomPositions;

            star.Bind(GL);
            GL.Begin(OpenGL.GL_QUADS);
            for (int a = 0; a < totalStars; a++)
            {
                // Setup randomized position.
                randomPositions = new Vector3f(
                    (float)rndm.NextDouble() * boundary.X - (boundary.X / 2),
                    (float)rndm.NextDouble() * boundary.Y - (boundary.Y / 2),
                    boundary.Z);
                // Setup randomized color.
                GL.Color(rndm.NextDouble(), rndm.NextDouble(), rndm.NextDouble());
                // Draw the star.
                GL.TexCoord(0f, 1f); GL.Vertex(randomPositions.X, randomPositions.Y, randomPositions.Z);
                GL.TexCoord(1f, 1f); GL.Vertex(randomPositions.X + starSize, randomPositions.Y, randomPositions.Z);
                GL.TexCoord(1f, 0f); GL.Vertex(randomPositions.X + starSize, randomPositions.Y + starSize, randomPositions.Z);
                GL.TexCoord(0f, 0f); GL.Vertex(randomPositions.X, randomPositions.Y + starSize, randomPositions.Z);
            }
            // Reset color.
            GL.Color(1f, 1f, 1f);
            GL.End();
        }

        private void DrawUI()
        {
            // Score and health text.
            string scoreText = ThePlayer.Score.ToString();
            string healthText = ThePlayer.Health.ToString();

            // The changing value, to animate the objects.
            float variable = (float)(ChangingValue * 0.01);

            if (GAME_READY)
            {
                // Title image.
                CustomGUIImage(TitleTexture, new Vector3f(0f, 0.25f, 2f), 2.76f, 1.81f);
                // Info image.
                CustomGUIImage(InfoTexture, new Vector3f(0f, -1.25f, 2f), 2.23f - variable, 0.77f - variable);
            }
            else if (GAME_BEGINS)
            {
                // Score text.
                GL.DrawText(
                    TheOpenGLControl.Width / 2 - 60, TheOpenGLControl.Height - 37, 1f, 1f, 0f, "Arial Bold", 37,
                    "Score:");
                GL.DrawText(
                    TheOpenGLControl.Width / 2 - (scoreText.Length * 22 / 2), TheOpenGLControl.Height - 87, 1f, 1f, 0f, "Arial Bold", 43,
                    scoreText);
                // Health text.
                GL.DrawText(
                    TheOpenGLControl.Width / 2 - 45, TheOpenGLControl.Height - 117, 1f, 1f, 0f, "Arial", 23,
                    "Health:");
                GL.DrawText(
                    TheOpenGLControl.Width / 2 - (healthText.Length * 15 / 2), TheOpenGLControl.Height - 147, 1f, 1f, 0f, "Arial Bold", 23,
                    healthText);
            }
            else if (GAME_ENDS)
            {
                // Score box.
                CustomGUIImage(FinalScoreTexture, new Vector3f(0f, -0.25f, 2f), 3.70f, 1.50f);
                // Score text.
                GL.DrawText(
                    TheOpenGLControl.Width / 2 - (scoreText.Length*65/2), TheOpenGLControl.Height / 2 - 65, 1f, 1f, 1f, "Arial Bold", 101,
                    scoreText);
            }
        }

        private void CustomLine(Vector3f pos1, Vector3f pos2, Vector3f col, float width)
        {
            GL.LineWidth(width);
            GL.Enable(OpenGL.GL_LINE_STIPPLE);
            GL.LineStipple(2, 0x1111);
            GL.Begin(OpenGL.GL_LINES);
            GL.Color(col.X, col.Y, col.Z);
            GL.Vertex(pos1.X, pos1.Y, pos1.Z);
            GL.Vertex(pos2.X, pos2.Y, pos2.Z);
            GL.End();
            GL.Disable(OpenGL.GL_LINE_STIPPLE);
        }

        private void CustomGUIImage(Texture tex, Vector3f pos, float wdth, float hght)
        {
            tex.Bind(GL);
            GL.Begin(OpenGL.GL_QUADS);
            GL.Color(1f, 1f, 1f);
            GL.TexCoord(0f, 1f); GL.Vertex(pos.X - (wdth / 2), pos.Y - (hght / 2), pos.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(pos.X + (wdth / 2), pos.Y - (hght / 2), pos.Z);
            GL.TexCoord(1f, 0f); GL.Vertex(pos.X + (wdth / 2), pos.Y + (hght / 2), pos.Z);
            GL.TexCoord(0f, 0f); GL.Vertex(pos.X - (wdth / 2), pos.Y + (hght / 2), pos.Z);
            GL.End();
        }

        private void CustomCube(Vector3f size, Vector3f pos, float angle, Vector3f rotAxis, Vector3f pivot, Texture tex)
        {
            GL.Translate(pos.X, pos.Y, pos.Z);
            GL.Rotate(angle, rotAxis.X, rotAxis.Y, rotAxis.Z);
            // ------------------------------ left vertex.
            float xcoef = 0f - (size.X * pivot.X);
            // ------------------------------ bottom vertex.
            float ycoef = 0f - (size.Y * pivot.Y);
            // ------------------------------ back vertex.
            float zcoef = 0f - (size.Z * pivot.Z);
            tex.Bind(GL);
            GL.Begin(OpenGL.GL_QUADS);
            // ------------------------------ Quad bottom.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            // ------------------------------ Quad back.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef + size.Y, zcoef);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef);
            // ------------------------------ Quad up.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef + size.Y, zcoef);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef + size.Z);
            // ------------------------------ Quad front.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            // ------------------------------ Quad right.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef + size.Y, zcoef + size.Z);
            // ------------------------------ Quad left.
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef, ycoef + size.Y, zcoef);
            GL.End();
        }

        private void CustomPrism(Vector3f size, Vector3f pos, float angle, Vector3f rotAxis, Vector3f pivot, Texture tex)
        {
            GL.Translate(pos.X, pos.Y, pos.Z);
            GL.Rotate(angle, rotAxis.X, rotAxis.Y, rotAxis.Z);
            // ------------------------------ left vertex.
            float xcoef = 0f - (size.X * pivot.X);
            // ------------------------------ bottom vertex.
            float ycoef = 0f - (size.Y * pivot.Y);
            // ------------------------------ back vertex.
            float zcoef = 0f - (size.Z * pivot.Z);
            tex.Bind(GL);
            GL.Begin(OpenGL.GL_TRIANGLES);
            // ------------------------------ Tris front.
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(0.5f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef);
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            // ------------------------------ Tris back.
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(0.5f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            GL.End();
            GL.Begin(OpenGL.GL_QUADS);
            // ------------------------------ Quad left.
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef);
            // ------------------------------ Quad right.
            GL.TexCoord(0f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            GL.TexCoord(1f, 0f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + size.Z);
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef);
            GL.End();
        }

        private void CustomCone(Vector3f size, Vector3f pos, float angle, Vector3f rotAxis, Vector3f pivot, Texture tex)
        {
            GL.Translate(pos.X, pos.Y, pos.Z);
            GL.Rotate(angle, rotAxis.X, rotAxis.Y, rotAxis.Z);
            // ------------------------------ left vertex.
            float xcoef = 0f - (size.X * pivot.X);
            // ------------------------------ bottom vertex.
            float ycoef = 0f - (size.Y * pivot.Y);
            // ------------------------------ back vertex.
            float zcoef = 0f - (size.Z * pivot.Z);
            tex.Bind(GL);
            GL.Begin(OpenGL.GL_TRIANGLES);
            // ------------------------------ Tris front.
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(0.5f, 0f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + (size.Z / 2));
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            // ------------------------------ Tris back.
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(0.5f, 0f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + (size.Z / 2));
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            // ------------------------------ Tris left.
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef, ycoef, zcoef);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef, ycoef, zcoef + size.Z);
            GL.TexCoord(0.5f, 0f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + (size.Z / 2));
            // ------------------------------ Tris right.
            GL.TexCoord(0f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef);
            GL.TexCoord(1f, 1f); GL.Vertex(xcoef + size.X, ycoef, zcoef + size.Z);
            GL.TexCoord(0.5f, 0f); GL.Vertex(xcoef + (size.X / 2), ycoef + size.Y, zcoef + (size.Z / 2));
            GL.End();
        }

        private void StarShip(Vector3f pos, float rotAngle, Vector3f rotAxis)
        {
            PlayerBehaviour(); // Update Player behaviour.

            GL.PushMatrix();
            CustomCube( // Create body.
                new Vector3f(0.75f, 0.5f, 1.25f), pos, rotAngle, rotAxis,
                new Vector3f(0.5f, 0.5f, 1f), BodyTexture);
            CustomCube( // Create cockpit.
                new Vector3f(0.375f, 0.25f, 0.5f), new Vector3f(0f, 0.25f, -0.25f), 0f, new Vector3f(0f, 0f, 0f),
                new Vector3f(0.5f, 0f, 1f), CockpitTexture);
            GL.PushMatrix();
            CustomCone( // Create nose.
                new Vector3f(0.75f, 1.5f, 0.5f), new Vector3f(0f, 0f, -1f), -90f, new Vector3f(1f, 0f, 0f),
                new Vector3f(0.5f, 0f, 1f), NoseTexture);
            GL.PopMatrix();
            GL.PushMatrix();
            CustomPrism( // Create wing 1.
                new Vector3f(0.5f, 1f, 1.25f), new Vector3f(-0.375f, 0f, -0.375f), 90f, new Vector3f(0f, 0f, 1f),
                new Vector3f(1f, 0f, 0.5f), WingTexture);
            GL.PopMatrix();
            GL.PushMatrix();
            CustomPrism( // Create wing 2.
                new Vector3f(0.5f, 1f, 1.25f), new Vector3f(0.375f, 0f, -0.375f), -90f, new Vector3f(0f, 0f, 1f),
                new Vector3f(0f, 0f, 0.5f), WingTexture);
            GL.PopMatrix();
            GL.PushMatrix();
            CustomCube( // Create emission tube 1.
                new Vector3f(0.25f, 0.15f, 0.25f), new Vector3f(-0.15f, -0.25f, 0.25f), 0f, new Vector3f(0f, 0f, 0f),
                new Vector3f(1f, 0f, 0f), EmissionTexture);
            GL.PopMatrix();
            GL.PushMatrix();
            CustomCube( // Create emission tube 2.
                new Vector3f(0.25f, 0.15f, 0.25f), new Vector3f(0.15f, -0.25f, 0.25f), 0f, new Vector3f(0f, 0f, 0f),
                new Vector3f(0f, 0f, 0f), EmissionTexture);
            GL.PopMatrix();
            GL.PopMatrix();
        }

        private void MeteorManifest()
        {
            for (int a = 0; a < Meteors.Length; a++)
            {
                // Draw meteor.
                if (Meteors[a].Active)
                {
                    GL.PushMatrix();
                    CustomCube(
                        new Vector3f(0.65f, 0.65f, 0.65f), Meteors[a].Position, Meteors[a].Angle,
                        Meteors[a].Rotation, new Vector3f(0.5f, 0.5f, 0.5f), MeteorTextures[Meteors[a].Type]);
                    GL.PopMatrix();
                    // Update meteor behaviour.
                    MeteorBehaviour(a);
                }
                else
                    // Reset meteor properties.
                    Meteors[a].Reset(RandomInstance, ThePlayer.Boundary.X, ThePlayer.Boundary.Y, Difficulty);
            }
        }

        private void BeamManifest()
        {
            for (int a = 0; a < Beams.Length; a++)
            {
                // Draw beam.
                if (Beams[a].Active)
                {
                    GL.PushMatrix();
                    CustomCube(
                        new Vector3f(0.1f, 0.1f, 1f), Beams[a].Position, Beams[a].Angle,
                        Beams[a].Rotation, new Vector3f(0.5f, 0.5f, 0.5f), BeamTexture);
                    GL.PopMatrix();
                    // Update beam behaviour.
                    BeamBehaviour(a);
                }
                else
                {
                    // Reset beam properties.
                    Beams[a].Reset(ThePlayer.Position, ThePlayer.Rotation, new Vector3f(0f, 0f, 1f));
                    if (ThePlayer.Shooting)
                    {
                        Beams[a].Active = true;
                        ThePlayer.Shooting = false;
                    }
                }
            }
        }

        private void ExplosionManifest()
        {
            for (int a = 0; a < Explosions.Length; a++)
            {
                // Draw explosion.
                if (Explosions[a].Active)
                {
                    CustomGUIImage(ExplosionTexture, Explosions[a].Position,
                        Explosions[a].DefaultScale.X - ((float)ChangingValue / 10f * 0.5f),
                        Explosions[a].DefaultScale.Y - ((float)ChangingValue / 10f * 0.5f));
                    // Update meteor behaviour.
                    ExplosionBehaviour(a);
                }
            }
        }

        private void HitManifest()
        {
            if (TheHitEffect.Active)
            {
                CustomGUIImage(HitTexture, ThePlayer.Position, TheHitEffect.Scale.X, TheHitEffect.Scale.Y);
                HitBehaviour();
            }
        }

        private void ScoreEffectManifest()
        {
            for (int a = 0; a < ScoreEffects.Length; a++)
            {
                if (ScoreEffects[a].Active)
                {
                    CustomGUIImage(ScoreTextures[a], ScoreEffects[a].Position, 1.03f, 1.03f);
                    ScoreEffectBehaviour(a);
                }
            }
        }

        private void PlayerBehaviour()
        {
            // Moves left.
            if (ThePlayer.MoveLeft && ThePlayer.Position.X > -ThePlayer.Boundary.X && ThePlayer.Speed > -ThePlayer.MaxSpeed)
            {
                ThePlayer.Speed -= 0.25f;
            }
            // Moves right.
            if (ThePlayer.MoveRight && ThePlayer.Position.X < ThePlayer.Boundary.X && ThePlayer.Speed < ThePlayer.MaxSpeed)
            {
                ThePlayer.Speed += 0.25f;
            }
            // Update position and rotation.
            ThePlayer.Position.X += ThePlayer.Speed;
            ThePlayer.Position.Y = (1 - Math.Abs(ThePlayer.Position.X / ThePlayer.Boundary.X)) * -ThePlayer.Boundary.Y;
            ThePlayer.Rotation = -(ThePlayer.Position.X / -ThePlayer.Boundary.X) * 60;
            // Decrease speed, so it moves smoothly.
            ThePlayer.Speed /= 1.5f;
            // Clamp the position.
            if (ThePlayer.Position.X < -ThePlayer.Boundary.X)
                ThePlayer.Position.X = -ThePlayer.Boundary.X;
            else if (ThePlayer.Position.X > ThePlayer.Boundary.X)
                ThePlayer.Position.X = ThePlayer.Boundary.X;
            // Check health.
            if (ThePlayer.Health < 5)
            {
                GAME_BEGINS = false;
                GAME_ENDS = true;
                MediaPlayerTheme.controls.stop();
                MediaPlayerTheme.currentMedia = ThemeSound2;
                MediaPlayerTheme.settings.volume = 100;
                MediaPlayerTheme.controls.play(); // Play theme sound.
                PlaySoundEffect(PlaySound);
            }
        }

        private void MeteorBehaviour(int index)
        {
            if (Meteors[index].Position.Z < ThePlayer.Position.Z + 3f)
            {
                Meteors[index].Position.Z += Meteors[index].Speed;
                Meteors[index].Angle += Meteors[index].Speed * 5;
                // Check collision with beams.
                for(int a=0; a<Beams.Length; a++)
                {
                    if (CollisionDetected(Meteors[index].Position, Beams[a].Position, 0.65) &&
                        Beams[a].Active)
                    {
                        ThePlayer.Score += (10 + (Meteors[index].Type * 5)); // Increase score.
                        ScoreEffects[Meteors[index].Type].Reset(Meteors[index].Position); // Activate score effect.
                        Difficulty += 0.01f; // Increase difficulty.
                        PlaySoundEffect(ExplodeSound);
                        Beams[a].Active = false; // Deactivate beam.
                        Meteors[index].Active = false; // Deactivate meteor.
                        for (int b = 0; b < Explosions.Length; b++) // Activate explosion.
                        {
                            if (!Explosions[b].Active)
                            {
                                Explosions[b].Reset(Meteors[index].Position, Meteors[index].Speed * 3);
                                break;
                            }
                        }
                        break;
                    }
                }
                // Check collision with player.
                if (CollisionDetected(Meteors[index].Position, ThePlayer.Position, 1.0))
                {
                    ThePlayer.Health = (ushort)(ThePlayer.Health - 5); // Decrease health.
                    TheHitEffect.Reset(ThePlayer.Position); // Activate hit effect.
                    PlaySoundEffect(HitSound);
                    Meteors[index].Active = false; // Deactivate meteor.
                    // Activate explosion.
                }
            }
            else
                Meteors[index].Active = false;
        }

        private void BeamBehaviour(int index)
        {
            if (Beams[index].Position.Z > -19f)
                Beams[index].Position.Z -= Beams[index].Speed;
            else
                Beams[index].Active = false;
        }

        private void ExplosionBehaviour(int index)
        {
            if (Explosions[index].Position.Z < ThePlayer.Position.Z + 3f)
            {
                Explosions[index].Position.Z += Explosions[index].Speed;
            }
            else
                Explosions[index].Active = false;
        }

        private void HitBehaviour()
        {
            if (TheHitEffect.Scale.X > 0.5f)
            {
                TheHitEffect.Scale.X -= TheHitEffect.Speed;
                TheHitEffect.Scale.Y -= TheHitEffect.Speed;
            }
            else
                TheHitEffect.Active = false;
        }

        private void ScoreEffectBehaviour(int index)
        {
            if (ScoreEffects[index].Position.Y < 4f)
                ScoreEffects[index].Position.Y += ScoreEffects[index].Speed;
            else
                ScoreEffects[index].Active = false;
        }

        private void LineSight()
        {
            // Disable some parameters.
            GL.Disable(OpenGL.GL_BLEND);
            GL.Disable(OpenGL.GL_TEXTURE_2D);

            CustomLine( // Create a line sight 1.
                ThePlayer.Position,
                new Vector3f(ThePlayer.Position.X, ThePlayer.Position.Y, ThePlayer.Position.Z - 19f),
                new Vector3f(0.75f, 0.75f, 0.75f), 3.125f);
        }

        private void PlaySoundEffect(IWMPMedia media) 
        {
            // Go across media players to find which one is ready to play the sound.
            for(int a=0; a<MediaPlayerEffect.Length; a++)
            {
                try
                {
                    if (MediaPlayerEffect[a].playState == WMPPlayState.wmppsReady ||
                        MediaPlayerEffect[a].playState == WMPPlayState.wmppsUndefined ||
                        MediaPlayerEffect[a].playState == WMPPlayState.wmppsStopped ||
                        a == MediaPlayerEffect.Length - 1)
                    {
                        MediaPlayerEffect[a].controls.stop();
                        MediaPlayerEffect[a].currentMedia = media;
                        MediaPlayerEffect[a].controls.play();
                        break;
                    }
                }
                catch(System.Runtime.InteropServices.COMException e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        private bool CollisionDetected(Vector3f a, Vector3f b, double minDistance)
        {
            double distance = Math.Sqrt((double)(
                ((a.X - b.X) * (a.X - b.X)) +
                ((a.Y - b.Y) * (a.Y - b.Y)) +
                ((a.Z - b.Z) * (a.Z - b.Z))
                ));
            if (distance < minDistance)
                return true;
            else
                return false;
        }

        private void OpenLocalCamera()
        {
            // Show camera selection form.
            CameraSelection cameraSelection = new CameraSelection();
            if (cameraSelection.ShowDialog(this) == DialogResult.OK)
            {
                // Create video source from selected camera.
                VideoCaptureDevice theCamera = new VideoCaptureDevice(cameraSelection.SelectedCamera);

                // Close previous video source.
                VideoPlayer.SignalToStop();
                VideoPlayer.WaitForStop();

                // Choose the smallest video resolution as possible.
                int min = 2048;
                int minIndex = 0;
                for (int a = 0; a < theCamera.VideoCapabilities.Length; a++)
                {
                    if (min > theCamera.VideoCapabilities[a].FrameSize.Width)
                    {
                        min = theCamera.VideoCapabilities[a].FrameSize.Width;
                        minIndex = a;
                    }
                }
                theCamera.VideoResolution = theCamera.VideoCapabilities[minIndex];

                // Initialize variables that depend on camera frame size.
                int wdth = theCamera.VideoCapabilities[minIndex].FrameSize.Width;
                int hght = theCamera.VideoCapabilities[minIndex].FrameSize.Height;

                PreviousImage = new Color[wdth, hght];
                SubtractionResult = new Color[wdth, hght];
                PolarizationResult = new Color[wdth, hght];

                ImageParts = new ImagePart[3];
                ImageParts[0].Area = new Rectangle(0, 0, wdth / 3, hght / 2);
                ImageParts[1].Area = new Rectangle(wdth * 2 / 3, 0, wdth, hght / 2);
                ImageParts[2].Area = new Rectangle(0, hght * 2 / 3, wdth, hght);
                for (int a = 0; a < ImageParts.Length; a++)
                    ImageParts[a].TotalWhiteDetected = 0;

                // Set the new video source.
                VideoPlayer.VideoSource = theCamera;
                VideoPlayer.Start();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge.Video.DirectShow;

namespace BadaiAngkasa
{
    public partial class CameraSelection : Form
    {
        public CameraSelection()
        {
            InitializeComponent();
        }

        private void CameraSelection_Load(object sender, EventArgs e)
        {
            EnumerateCameraDevices();
        }

        private FilterInfoCollection DetectedCameraDevices;
        public string SelectedCamera;

        private void EnumerateCameraDevices()
        {
            SelectButton.Enabled = false;
            try
            {
                // Enumerate video devices.
                DetectedCameraDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (DetectedCameraDevices.Count == 0)
                    throw new ApplicationException();
                foreach (FilterInfo cameraItem in DetectedCameraDevices)
                    ComboBoxCamera.Items.Add(cameraItem.Name);
            }
            catch (ApplicationException e)
            {
                ComboBoxCamera.Items.Add("I'm sorry, no camera detected !");
                ComboBoxCamera.Enabled = false;
                SelectButton.Enabled = false;
            }
        }

        private void ComboBoxCamera_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectButton.Enabled = true;
        }

        private void SelectButton_Click(object sender, EventArgs e)
        {
            SelectedCamera = DetectedCameraDevices[ComboBoxCamera.SelectedIndex].MonikerString;
        }
    }
}

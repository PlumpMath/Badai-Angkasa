﻿namespace BadaiAngkasa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TheOpenGLControl = new SharpGL.OpenGLControl();
            this.VideoPlayer = new AForge.Controls.VideoSourcePlayer();
            this.TheTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.TheOpenGLControl)).BeginInit();
            this.TheOpenGLControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // TheOpenGLControl
            // 
            this.TheOpenGLControl.AutoSize = true;
            this.TheOpenGLControl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TheOpenGLControl.Controls.Add(this.VideoPlayer);
            this.TheOpenGLControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TheOpenGLControl.DrawFPS = true;
            this.TheOpenGLControl.FrameRate = 28;
            this.TheOpenGLControl.Location = new System.Drawing.Point(0, 0);
            this.TheOpenGLControl.MaximumSize = new System.Drawing.Size(1366, 768);
            this.TheOpenGLControl.MinimumSize = new System.Drawing.Size(800, 600);
            this.TheOpenGLControl.Name = "TheOpenGLControl";
            this.TheOpenGLControl.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.TheOpenGLControl.RenderContextType = SharpGL.RenderContextType.FBO;
            this.TheOpenGLControl.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.TheOpenGLControl.Size = new System.Drawing.Size(800, 600);
            this.TheOpenGLControl.TabIndex = 0;
            this.TheOpenGLControl.OpenGLDraw += new SharpGL.RenderEventHandler(this.TheOpenGLControl_OpenGLDraw);
            this.TheOpenGLControl.Load += new System.EventHandler(this.TheOpenGLControl_Load);
            this.TheOpenGLControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDownListener);
            this.TheOpenGLControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressListener);
            this.TheOpenGLControl.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyUpListener);
            // 
            // VideoPlayer
            // 
            this.VideoPlayer.AllowDrop = true;
            this.VideoPlayer.BackColor = System.Drawing.SystemColors.WindowText;
            this.VideoPlayer.BorderColor = System.Drawing.Color.DimGray;
            this.VideoPlayer.ForeColor = System.Drawing.SystemColors.WindowText;
            this.VideoPlayer.Location = new System.Drawing.Point(50, 10);
            this.VideoPlayer.Margin = new System.Windows.Forms.Padding(0);
            this.VideoPlayer.Name = "VideoPlayer";
            this.VideoPlayer.Size = new System.Drawing.Size(120, 96);
            this.VideoPlayer.TabIndex = 0;
            this.VideoPlayer.TabStop = false;
            this.VideoPlayer.VideoSource = null;
            this.VideoPlayer.NewFrame += new AForge.Controls.VideoSourcePlayer.NewFrameHandler(this.WebcamListener);
            // 
            // TheTimer
            // 
            this.TheTimer.Enabled = true;
            this.TheTimer.Interval = 25;
            this.TheTimer.Tick += new System.EventHandler(this.TheTimerTick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.TheOpenGLControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Badai Angkasa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.TheOpenGLControl)).EndInit();
            this.TheOpenGLControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private SharpGL.OpenGLControl TheOpenGLControl;
        private System.Windows.Forms.Timer TheTimer;
        private AForge.Controls.VideoSourcePlayer VideoPlayer;
    }
}

